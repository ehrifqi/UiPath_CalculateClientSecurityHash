1.To run this project first you need an account in ACME website, To Create account Go to the https://acme-test.uipath.com
 If you have an account already u can skip first step

2.Open the https://platform.uipath.com and Login 

3.Now Go to the assets and add a Asset

4.In type field select the credential 

5.Now add your usename and password in their respective field

6.In the Asset Name field type "ACME Credential" as it is, this is important

7.Save the asset and you ready to go.

8.Open project in UIpath and run it.

If any problem occured ping me at Vikrant.mnnit00@gmail.com

# CalculateClientSecurityHash
